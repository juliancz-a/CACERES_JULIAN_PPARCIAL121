
package zoologico;


public class Reptil extends Animal{
    private String tipoEscama;
    private String regTemperatura;

    public Reptil(String tipoEscama, String regTemperatura, String nombre, int edad) {
        super(nombre, edad);
        this.tipoEscama = tipoEscama;
        this.regTemperatura = regTemperatura;
    }

    @Override
    public String toString() {
        return "Reptil{" + "tipoEscama=" + tipoEscama + ", regTemperatura=" + regTemperatura + '}';
    }
    
    
    
}


package zoologico;

public interface Vacunable {
    boolean vacunar();
}

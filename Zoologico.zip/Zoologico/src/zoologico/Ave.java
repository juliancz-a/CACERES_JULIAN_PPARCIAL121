
package zoologico;

public class Ave extends Animal implements Vacunable{
    
    private double envergaduraAlas;
    private boolean vacunado;

    public Ave(String nombre, int edad, double envergaduraAlas, boolean vacunado) {
        super(nombre, edad);
        
        verificarEnvergaduraAlas(envergaduraAlas);
        this.envergaduraAlas = envergaduraAlas;
        this.vacunado = vacunado;
    }

    @Override
    public String toString() {
        return "Ave{" + "envergaduraAlas=" + envergaduraAlas + '}';
    }
    
    
    @Override
    public boolean vacunar() {
        if (vacunado == false) {    
            this.vacunado = true;
            return true;
        }
        
        return false;
    }
    
    
    private void verificarEnvergaduraAlas(double envergaduraAlas) {
        if(envergaduraAlas < 0.0) {
            throw new IllegalArgumentException();
        }
    }
    
}

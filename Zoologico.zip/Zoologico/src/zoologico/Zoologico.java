
package zoologico;

import java.util.ArrayList;
import java.util.List;

public class Zoologico {
    private String nombreZoo;
    private List<Animal> animales;

    public Zoologico(String nombreZoo) {
        this.nombreZoo = nombreZoo;
        this.animales = new ArrayList<>();
    }
    
    public void agregarAnimal(Animal animal){
        verificarAnimal(animal);
        animales.add(animal);
 
    }
    
    private void verificarAnimal(Animal animal) {
        
        //verificar si el animal se encuentra en el array (si dos objetos poseen el mismo nombre y edadse consideran iguales)
        if (animales.contains(animal)) {
            throw new RepeatedAnimalException();     
        }
        
        if(animal == null) {
            throw new NullPointerException();
        }
    }
    
    public void mostrarAnimales() {
        for(Animal a : animales) {     
            System.out.println(a);
        }
      
    }
    
    public void vacunarAnimales() {
        for(Animal a : animales) {
            if(a instanceof Vacunable vacunable && vacunable.vacunar()){
                // Un animal debe implementar la interfaz vacunable para saber si puede ser vacunado, caso contrario será un animal no vacunable
                System.out.println("Un animal ha sido vacunado:\n" + a + "\n");
            } else
            {
                System.out.println("Un animal no se ha podido vacunar:\n" + a + "\n");
            }
                
        }
    }
    
}

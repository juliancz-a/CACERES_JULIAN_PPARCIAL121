
package zoologico;

public class Tester {

   
    public static void main(String[] args) {
        
        Zoologico zoo = new Zoologico("MyZoo");
        
        cargarZoo(zoo);
        zoo.mostrarAnimales();
        zoo.vacunarAnimales();
        
    }
    
    public static void cargarZoo(Zoologico zoo) {
        
        //Carga de datos para el Zoologico
        
        try {
            
        // CODIGO SUSCEPTIBLE A ARGUMENTOS ILEGALES [EDADES MENORES A 0, PESOS NEGATIVOS, ETC]
        Ave ave1 = new Ave("Pepito", 10, 10, true);
        Ave ave2 = new Ave("Lolo", 5, 20, false);
        Ave ave3 = new Ave("Pancho", 1, 5, false);
        
        Reptil reptil1 = new Reptil("queratinosa", "ectotermia", "PepitoReptil", 5);
        Reptil reptil2 = new Reptil("queratinosa", "ectotermia", "LolitoReptil", 3);
        
        Mamifero mamifero1 = new Mamifero("Firulais", 10, 20, Dietas.CARNIVORO, true);
        Mamifero mamifero2 = new Mamifero("Panchito", 5, 40, Dietas.OMNIVORO, false);
        Mamifero mamifero3 = new Mamifero("Carlitos", 2, 5, Dietas.HERVIBORO, true);
        
        
        Mamifero mamifero4 = new Mamifero("Carlitos", 2, 54, Dietas.CARNIVORO, true); 
        
        
        // CODIGO SUSCEPTIBLE A ERRORES DE REPETICION / NULL POINTERS
        
        zoo.agregarAnimal(ave1);
        zoo.agregarAnimal(ave2);
        zoo.agregarAnimal(ave3);
        zoo.agregarAnimal(reptil1);
        zoo.agregarAnimal(reptil2);
        zoo.agregarAnimal(mamifero1);
        zoo.agregarAnimal(mamifero2);
        zoo.agregarAnimal(mamifero3);
        
            // Repetidos o nulos
        zoo.agregarAnimal(null);
        zoo.agregarAnimal(mamifero4);
        }
        catch (RepeatedAnimalException | NullPointerException ex){
            System.out.println("Ha ocurrido un error: " + ex.getMessage());
        } 
        catch (IllegalArgumentException ex) {
            System.out.println("Se ha ingresado un valor inválido en los datos de los animales");
        }
    
        
        
       
       
    }
    
}

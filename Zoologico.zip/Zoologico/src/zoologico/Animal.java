
package zoologico;

import java.util.Objects;


public abstract class Animal {
    
    
    private String nombre;
    private int edad;

    public Animal(String nombre, int edad) {
        this.nombre = nombre;
        
        verificarEdad(edad);
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", edad=" + edad + '}';
    }

        
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if(obj instanceof Animal a) {
            return (a.edad == edad && a.nombre.equals(nombre));
        }
       
        //el retorno será falso si el obj no es instancia de animal o no se evalua el mismo obj (será entonces instancia de otra clase, o null)
        return false;
     
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(edad, nombre);
    }
    
    private void verificarEdad(int edad) {
        if(edad < 0) {
            throw new IllegalArgumentException();
        }
    }
    
    
    
    
}

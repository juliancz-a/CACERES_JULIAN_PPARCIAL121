
package zoologico;

public class RepeatedAnimalException extends RuntimeException{
    
    private static final String MESSAGE = "Un animal ya se encuentra en el zoólogico.";

    public RepeatedAnimalException() {
        super(MESSAGE);
    }
    
    
    
    
}

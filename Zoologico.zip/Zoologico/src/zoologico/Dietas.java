
package zoologico;

public enum Dietas {
    
    HERVIBORO,
    CARNIVORO,
    OMNIVORO
    
}

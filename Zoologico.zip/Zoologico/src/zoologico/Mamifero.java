
package zoologico;


public class Mamifero extends Animal implements Vacunable{
    private double peso;
    private Dietas dieta;
    private boolean vacunado;

    public Mamifero(String nombre, int edad, double peso, Dietas dieta, boolean vacunado) {
        super(nombre, edad);
        
        verificarPeso(peso);
        this.peso = peso;
        this.dieta = dieta;
        this.vacunado = vacunado;
    }

    @Override
    public String toString() {
        return "Mamifero{" + "peso=" + peso + ", dieta=" + dieta + '}';
    }
    
    @Override
    public boolean vacunar() {
        //retorna TRUE si ha podido ser vacunado el animal, y se lo vacuna,  caso contrario = FALSE
        if (vacunado == false) {    
            this.vacunado = true;
            return true;
        }
        
        return false;
    }
    
    
    private void verificarPeso(double peso) {
        if (peso < 0.0 ) {
            throw new IllegalArgumentException();
        }
    }
    
    
}
